package ir.hesabdar.app;

import android.content.Intent;
import android.provider.AlarmClock;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.PluginMethod;

@CapacitorPlugin(name = "SystemAlarm")
public class SystemAlarmPlugin extends Plugin {
    @PluginMethod
    public void addAlarm(PluginCall call) {
        int hour = call.getInt("hour", -1);
        int minute = call.getInt("minute", -1);
        String message = call.getString("message", "یادآوری حسابدار");
        if (hour < 0 || hour > 23 || minute < 0 || minute > 59) {
            call.reject("زمان آلارم نامعتبر است"); return;
        }
        try {
            Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM);
            intent.putExtra(AlarmClock.EXTRA_HOUR, hour);
            intent.putExtra(AlarmClock.EXTRA_MINUTES, minute);
            intent.putExtra(AlarmClock.EXTRA_MESSAGE, message);
            intent.putExtra(AlarmClock.EXTRA_SKIP_UI, false);
            if (intent.resolveActivity(getContext().getPackageManager()) == null) {
                call.reject("برنامه ساعت/آلارم روی دستگاه پیدا نشد"); return;
            }
            getContext().startActivity(intent);
            JSObject ret = new JSObject(); ret.put("added", true); call.resolve(ret);
        } catch (Exception e) { call.reject("افزودن آلارم به برنامه ساعت ناموفق بود", e); }
    }
}
