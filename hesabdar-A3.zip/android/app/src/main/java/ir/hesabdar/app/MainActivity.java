package ir.hesabdar.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(android.os.Bundle savedInstanceState) {
        registerPlugin(SystemAlarmPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
