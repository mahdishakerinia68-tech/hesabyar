import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const index=readFileSync('index.html','utf8'), sw=readFileSync('sw.js','utf8'), app=readFileSync('app.js','utf8');
assert.match(index,/sw\.js\?v=1-2-8/); assert.doesNotMatch(index,/maximum-scale=1/); assert.match(sw,/hesabdar-1-2-8-offline-v3/); assert.match(app,/APP_VERSION="1\.2\.8"/); assert.doesNotMatch(app,/saveAnthropicKey|clearAnthropicKey/);
console.log('e2e-smoke: PASS (static PWA/security/startup checks)');
