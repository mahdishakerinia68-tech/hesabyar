export const moduleName='biometric';
