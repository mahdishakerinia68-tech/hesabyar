export const moduleName='customers';
