export const moduleName='people';
