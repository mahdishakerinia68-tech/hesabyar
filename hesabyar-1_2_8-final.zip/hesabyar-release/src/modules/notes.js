export const moduleName='notes';
