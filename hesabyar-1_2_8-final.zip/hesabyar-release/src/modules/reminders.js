export const moduleName='reminders';
