const DB_NAME = 'hesabdar-v4';
const DB_VERSION = 1;
const STORES = ['accounts','transactions','invoices','customers','products','people','checks','notes','reminders','audit','attachments','trash','expenseCats','incomeCats','syncMetadata','meta'];
let dbPromise;
export function openDatabase() {
  if (dbPromise) return dbPromise;
  if (!('indexedDB' in globalThis)) return Promise.reject(new Error('IndexedDB در این دستگاه در دسترس نیست'));
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => { const db = req.result; for (const store of STORES) if (!db.objectStoreNames.contains(store)) db.createObjectStore(store, { keyPath: 'id' }); };
    req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error || new Error('IndexedDB unavailable'));
  });
  return dbPromise;
}
export async function putRecord(store, record) { const db = await openDatabase(); return new Promise((resolve,reject)=>{const tx=db.transaction(store,'readwrite');tx.objectStore(store).put(record);tx.oncomplete=()=>resolve(record);tx.onerror=()=>reject(tx.error);}); }
export async function getRecord(store,id){const db=await openDatabase();return new Promise((resolve,reject)=>{const r=db.transaction(store).objectStore(store).get(id);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
export async function deleteRecord(store,id){const db=await openDatabase();return new Promise((resolve,reject)=>{const tx=db.transaction(store,'readwrite');tx.objectStore(store).delete(id);tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);});}
export async function getAllRecords(store){const db=await openDatabase();return new Promise((resolve,reject)=>{const r=db.transaction(store).objectStore(store).getAll();r.onsuccess=()=>resolve(r.result||[]);r.onerror=()=>reject(r.error);});}
export async function saveSnapshot(data) {
  const db = await openDatabase();
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(STORES,'readwrite');
    for (const store of STORES) tx.objectStore(store).clear();
    for (const store of STORES) for (const record of (data[store]||[])) tx.objectStore(store).put(record);
    tx.objectStore('meta').put({id:'root', schemaVersion:data.schemaVersion, appVersion:'1.2.8', savedAt:new Date().toISOString()});
    tx.objectStore('syncMetadata').put({id:'root', value:data._sync||{tombstones:{}}});
    tx.oncomplete=()=>resolve(true); tx.onerror=()=>reject(tx.error||new Error('IndexedDB transaction failed')); tx.onabort=()=>reject(tx.error||new Error('IndexedDB transaction aborted'));
  });
}
export async function exportDatabaseSnapshot(){const out={};for(const store of STORES.filter(s=>!['meta','syncMetadata'].includes(s)))out[store]=await getAllRecords(store);out._sync=(await getRecord('syncMetadata','root'))?.value||{tombstones:{}};return out;}
export async function migrateLocalStorageToIndexedDB({keys=[],remove=true}={}) {
  const raw = keys.map(k=>localStorage.getItem(k)).find(Boolean); if (!raw) return false;
  const data = JSON.parse(raw); await saveSnapshot(data); if(remove) for(const k of keys) localStorage.removeItem(k); return true;
}
export async function hydrateFromIndexedDB(blank) {
  try { const data=await exportDatabaseSnapshot(); const has=Object.values(data).some(v=>Array.isArray(v)&&v.length); return has ? data : blank; }
  catch { return blank; }
}
