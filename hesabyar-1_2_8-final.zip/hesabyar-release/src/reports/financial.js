export const moduleName='financial';
